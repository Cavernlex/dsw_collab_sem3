<?php
 $con=mysqli_connect("localhost","root","","mussic123"); 
 if (mysqli_connect_errno()) 
 { 
 echo "Failed to connect to MySQL: " . mysqli_connect_error(); 
  } 
 
$sql="INSERT INTO login (email, password) 
VALUES ('$_POST[email]','$_POST[password]')";  
 
if (!mysqli_query($con,$sql))  
 {   die('Error: ' . mysqli_error());   } 
 echo "1 record added"; 
 
mysqli_close($con);
 ?> 